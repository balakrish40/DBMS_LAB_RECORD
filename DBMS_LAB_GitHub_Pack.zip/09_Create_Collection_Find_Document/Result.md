# Result

Expected result: findOne returns the matching document, the aggregation lists first names occurring more than once and their users, and the age query returns users older than 12. If the collection already exists with these _id values, remove or change the sample IDs before inserting again.
