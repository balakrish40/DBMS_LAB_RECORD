# Create Collection and Find Documents

Technology: MongoDB

```javascript
use e_shopping

db.student.insertMany([
  {_id: 1, firstname: "Adhi", lastname: "Ravi", age: 16, email: "adhiravi@gmail.com"},
  {_id: 2, firstname: "Adhi", lastname: "Mani", age: 12, email: "dhivya@gmail.com"},
  {_id: 3, firstname: "Balu", lastname: "Velu", age: 15, email: "balu@gmail.com"}
])

// Find a document by ID
db.student.findOne({_id: 2})

// Find a user by email
db.student.findOne({email: "adhiravi@gmail.com"})

// Find all users with the same first name
db.student.aggregate([
  {$group: {_id: "$firstname", count: {$sum: 1}, users: {$push: "$$ROOT"}}},
  {$match: {count: {$gt: 1}}}
])

// Find users older than 12
db.student.find({age: {$gt: 12}})
```
