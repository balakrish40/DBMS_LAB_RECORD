# Aim

To create student documents and find by ID, email, first name, and age.
