# Online Reservation System

Technology: MySQL

```sql
CREATE DATABASE reservation_db;
USE reservation_db;

CREATE TABLE customer (
  c_id INT PRIMARY KEY,
  c_name VARCHAR(30),
  email VARCHAR(50),
  phonenumber VARCHAR(15)
);

CREATE TABLE vehicle (
  vid INT PRIMARY KEY,
  v_type ENUM('car','van','bus'),
  capacity INT
);

INSERT INTO vehicle VALUES
(1001,'car',4), (1200,'van',10), (1201,'bus',52);

CREATE TABLE reserve (
  r_id INT PRIMARY KEY,
  c_id INT,
  vid INT,
  start_datetime DATETIME,
  end_datetime DATETIME,
  place VARCHAR(15),
  CHECK (start_datetime >= '2025-10-25'),
  FOREIGN KEY (c_id) REFERENCES customer(c_id),
  FOREIGN KEY (vid) REFERENCES vehicle(vid)
);

SELECT * FROM vehicle;
SELECT * FROM reserve;
```
