# Aim

To create customer, vehicle and reservation tables and apply data type and check constraints.
