# Result

Expected result: vehicle records display with their type and capacity. Reservation records must refer to existing customer and vehicle IDs. The CHECK constraint rejects start dates earlier than the specified date in MySQL versions that enforce CHECK constraints.
