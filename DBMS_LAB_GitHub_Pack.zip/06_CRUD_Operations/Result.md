# Result

Expected result: insertOne/insertMany add documents, findOne/find display them, updateOne changes one matching document, updateMany changes all matching documents, and deleteOne/deleteMany remove matching documents. Run delete commands last because they remove data.
