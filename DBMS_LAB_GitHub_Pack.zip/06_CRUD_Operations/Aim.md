# Aim

To perform create, read, update and delete operations on a shop collection.
