# Algorithm

Algorithm:
1. Start the program.
2. Select the required MongoDB database.
3. Create the required table or collection.
4. Insert the sample records.
5. Execute the queries for crud operations.
6. Display the result.
7. Stop the program.
