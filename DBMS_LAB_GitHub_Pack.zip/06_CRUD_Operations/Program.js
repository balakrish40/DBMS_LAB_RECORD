# CRUD Operations

Technology: MongoDB

```javascript
use e_shopping

db.createCollection("collegeshop")

db.collegeshop.insertOne({item: "notebook", qty: 50})

db.collegeshop.insertMany([
  {item: "ballpointpen", qty: 100},
  {item: "inkpen", qty: 60}
])

// Read one or many
db.collegeshop.findOne({item: "ballpointpen"})
db.collegeshop.find()

// Update one
db.collegeshop.updateOne(
  {item: "notebook"},
  {$set: {category: "paperstuff"}}
)

// Update many matching documents
db.collegeshop.updateMany(
  {qty: {$gte: 60}},
  {$set: {status: "available"}}
)

// Delete one
db.collegeshop.deleteOne({item: "notebook"})

// Delete many matching documents
db.collegeshop.deleteMany({status: "available"})
```
