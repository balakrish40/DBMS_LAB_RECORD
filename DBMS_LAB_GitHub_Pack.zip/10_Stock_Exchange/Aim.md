# Aim

To import stock data from CSV and query stocks by profit and growth.
