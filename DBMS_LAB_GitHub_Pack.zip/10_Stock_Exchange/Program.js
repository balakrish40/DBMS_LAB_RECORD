# Stock Exchange Data

Technology: MongoDB

```javascript
use sample

// After importing stock_data.csv into collection stock_data in MongoDB Compass:

// Find stocks where profit is 0.5 or higher
db.stock_data.find({profit: {$gte: 0.5}})

// Find stocks with negative growth
db.stock_data.find({growth: {$lt: 0}})
```
