# Result

Expected result: the first query displays stock documents with profit >= 0.5; the second displays documents with negative growth. Import stock_data.csv using MongoDB Compass: select the stock collection, choose Import Data, select CSV, then import.
