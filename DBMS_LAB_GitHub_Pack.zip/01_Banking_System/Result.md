# Result

Expected result: bank and loandetails records are displayed. The INNER JOIN shows each customer with their matching loan ID and loan amount. Duplicate email/phone values are rejected by UNIQUE; loan rows with a missing bank account are rejected by the foreign key.
