# Banking System

Technology: MySQL

```sql
CREATE DATABASE dbms_lab;
USE dbms_lab;

CREATE TABLE bank (
  accno INT PRIMARY KEY,
  cust_name VARCHAR(25),
  email VARCHAR(100) UNIQUE,
  phonenumber VARCHAR(15) UNIQUE
);

INSERT INTO bank VALUES
(17071, 'Velan', 'velan1@gmail.com', '9788934500'),
(17072, 'Arun', 'arun@gmail.com', '6734517000'),
(17073, 'Shanthi', 'sanu21@gmail.com', '7890012345');

CREATE TABLE loandetails (
  loanid INT PRIMARY KEY,
  accno INT,
  loanamt INT,
  FOREIGN KEY (accno) REFERENCES bank(accno)
);

INSERT INTO loandetails VALUES (101, 17071, 50000), (102, 17072, 60000);

SELECT * FROM bank;
SELECT * FROM loandetails;

SELECT b.cust_name, l.loanid, l.loanamt
FROM bank b
INNER JOIN loandetails l ON b.accno = l.accno;
```
