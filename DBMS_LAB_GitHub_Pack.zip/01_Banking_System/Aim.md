# Aim

To create bank and loan details tables, apply primary/unique keys, and join related bank and loan data.
