# Result

Expected result: filters return only matching products, sort({price: 1}) orders lowest price first, sort({stock: -1}) orders highest stock first, and createIndex() creates a compound index on category and price.
