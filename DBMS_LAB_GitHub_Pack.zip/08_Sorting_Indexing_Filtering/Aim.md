# Aim

To filter products by category and price, sort results and create a compound index.
