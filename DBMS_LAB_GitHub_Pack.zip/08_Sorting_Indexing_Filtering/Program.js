# Sorting, Indexing and Filtering

Technology: MongoDB

```javascript
use e_shopping

// Insert sample products (skip if already inserted in Program 5)
db.product.insertMany([
  {name: "Laptop", category: "Electronics", price: 1200, stock: 50},
  {name: "Mouse", category: "Electronics", price: 25, stock: 200},
  {name: "Keyboard", category: "Electronics", price: 75, stock: 150},
  {name: "Desk Chair", category: "Furniture", price: 300, stock: 30},
  {name: "Coffee Table", category: "Furniture", price: 150, stock: 40}
])

// Filter by category and price
db.product.find({category: "Electronics", price: {$lt: 100}})

// Sort by price ascending
db.product.find().sort({price: 1})

// Furniture products sorted by stock descending
db.product.find({category: "Furniture"}).sort({stock: -1})

// Filter and sort by name
db.product.find({category: "Electronics", price: {$lt: 150}}).sort({name: 1})

// Create compound index
db.product.createIndex({category: 1, price: 1})
db.product.getIndexes()
```
