# DBMS Lab Record

This repository pack separates each practical into individual files: Aim, Algorithm, Program Code, and Result.

## Programs
1. Banking System (MySQL)
2. Online Reservation System (MySQL)
3. Personal Information (MySQL)
4. Student Mark Processing System (MySQL)
5. E-Commerce Product Catalog (MongoDB)
6. CRUD Operations (MongoDB)
7. Built-in Functions (MongoDB)
8. Sorting, Indexing and Filtering (MongoDB)
9. Create Collection and Find Documents (MongoDB)
10. Stock Exchange Data (MongoDB)

## Upload to GitHub
Open your `DBMS_LAB` repository → **Add file → Upload files**. Extract this ZIP on your computer first, then upload the files/folders and click **Commit changes**.

Note: SQL/MongoDB statements have been typed into editable text files for easier copying. Some code is a simplified, runnable version based on the lab record screenshots; check database names, existing collections and sample IDs before rerunning insert statements.
