# Aim

To create a product collection and insert sample e-commerce product documents.
