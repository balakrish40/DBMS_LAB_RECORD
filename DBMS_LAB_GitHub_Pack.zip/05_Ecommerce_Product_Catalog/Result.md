# Result

Expected result: eight product documents are inserted into the products collection and find() displays product name, category, price and stock.
