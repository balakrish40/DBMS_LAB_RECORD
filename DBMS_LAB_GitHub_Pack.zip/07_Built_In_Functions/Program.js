# Built-in Functions in MongoDB

Technology: MongoDB

```javascript
use e_shopping

db.s_mark.insertMany([
  {_id: 1, name: "Arun", java: 76, cn: 73, os: 98},
  {_id: 2, name: "Banu", java: 67, cn: 56, os: 76},
  {_id: 3, name: "Chitra", java: 89, cn: 67, os: 54},
  {_id: 4, name: "Dharshan", java: 73, cn: 45, os: 69}
])

// $add: calculate total marks
db.s_mark.aggregate([
  {$addFields: {totalmark: {$add: ["$java", "$cn", "$os"]}}}
])

// $add, $multiply, $divide: calculate percentage
db.s_mark.aggregate([
  {$addFields: {
    totalmark: {$add: ["$java", "$cn", "$os"]},
    percentage: {$multiply: [{$divide: [{$add: ["$java", "$cn", "$os"]}, 300]}, 100]}
  }}
])

// Add education status
db.s_mark.updateOne({_id: 1}, {$set: {edu_status: "regular"}})
db.s_mark.updateOne({_id: 2}, {$set: {edu_status: "intern"}})
db.s_mark.updateOne({_id: 3}, {$set: {edu_status: "regular"}})
db.s_mark.updateOne({_id: 4}, {$set: {edu_status: "intern"}})

// $match: filter regular students
db.s_mark.aggregate([{$match: {edu_status: "regular"}}])

// $match with condition
db.s_mark.aggregate([{$match: {edu_status: "intern", os: {$gte: 70}}}])

// $group, $avg and $sum: average marks and count by status
db.s_mark.aggregate([
  {$group: {
    _id: "$edu_status",
    avg_java: {$avg: "$java"},
    avg_cn: {$avg: "$cn"},
    avg_os: {$avg: "$os"},
    count: {$sum: 1}
  }}
])

// $count: count regular students
db.s_mark.aggregate([
  {$match: {edu_status: "regular"}},
  {$count: "totalRegularStudents"}
])

// $project and $limit
db.s_mark.aggregate([
  {$project: {_id: 0, name: 1, java: 1, edu_status: 1}},
  {$limit: 2}
])
```
