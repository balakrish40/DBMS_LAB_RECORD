# Result

Expected result: totalmark adds the three subject marks; percentage calculates marks out of 300; $match filters by education status and OS mark; $group returns status-wise averages and counts; $count counts regular students; $project displays selected fields and $limit returns two documents. For a clean rerun, drop the s_mark collection first if it already contains these _id values.
