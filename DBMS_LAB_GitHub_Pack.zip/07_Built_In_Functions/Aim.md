# Aim

To use arithmetic expressions and aggregation stages to calculate marks, filter students, group by status and project selected fields.
