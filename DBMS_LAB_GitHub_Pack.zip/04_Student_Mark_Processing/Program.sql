# Student Mark Processing System

Technology: MySQL

```sql
CREATE DATABASE student_db;
USE student_db;

CREATE TABLE studentdata (
  rollno VARCHAR(10) PRIMARY KEY,
  studentname VARCHAR(15),
  java INT,
  adbms INT,
  cn INT,
  os INT,
  d_net INT,
  total INT,
  percentage INT
);

INSERT INTO studentdata
(rollno, studentname, java, adbms, cn, os, d_net)
VALUES
('25mca01','Arun',50,57,67,78,50),
('25mca02','Banu',65,57,69,60,48),
('25mca03','Chitra',78,67,56,46,98);

UPDATE studentdata
SET total = java + adbms + cn + os + d_net;

UPDATE studentdata
SET percentage = total / 5;

SELECT * FROM studentdata;
SELECT rollno, java FROM studentdata WHERE java BETWEEN 45 AND 65;
SELECT rollno, java, d_net FROM studentdata WHERE java >= 45 AND d_net >= 45;
SELECT rollno, studentname FROM studentdata WHERE total > 302;
```
