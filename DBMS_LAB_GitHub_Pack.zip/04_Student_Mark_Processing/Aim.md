# Aim

To store student marks, calculate total and percentage, and filter marks using conditions.
