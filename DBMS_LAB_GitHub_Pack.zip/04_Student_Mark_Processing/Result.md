# Result

Expected result: total is calculated by adding the five subject marks and percentage is total divided by 5. The WHERE queries display only students matching the specified mark conditions.
