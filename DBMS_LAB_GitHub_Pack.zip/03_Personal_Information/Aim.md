# Aim

To create a personal information table, insert records and filter values using LIKE.
