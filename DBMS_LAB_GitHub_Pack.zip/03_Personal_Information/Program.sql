# Personal Information

Technology: MySQL

```sql
CREATE DATABASE personal_db;
USE personal_db;

CREATE TABLE personal_data (
  username VARCHAR(10),
  emailid VARCHAR(25),
  UG_University VARCHAR(25)
);

INSERT INTO personal_data VALUES
('sumathi','sumathi15@gmail.com','bharathiyar'),
('ravi','ravi23@gmail.com','bharathidasan'),
('keerthi','keerthi30@gmail.com','bharathiar'),
('kumar','kumar101@gmail.com','bharathiar');

SELECT * FROM personal_data;
SELECT * FROM personal_data WHERE emailid LIKE '%@gmail.com';
SELECT * FROM personal_data WHERE username LIKE 'r%';
SELECT * FROM personal_data WHERE UG_University LIKE '%ar%';
SELECT * FROM personal_data WHERE UG_University NOT LIKE 'h%';
```
