# Result

Expected result: the SELECT statement displays all inserted personal records. LIKE filters email, username and university values using patterns; NOT LIKE excludes matching patterns.
